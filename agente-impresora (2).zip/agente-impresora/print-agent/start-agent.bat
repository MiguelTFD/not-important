@echo off
title FacilComanda Print Agent
echo ===================================================
echo      FACILCOMANDA - AGENTE DE IMPRESION LOCAL
echo ===================================================
echo.
cd /d "%~dp0"

if not exist node_modules (
    echo Instalando dependencias necesarias ^(amqplib^)...
    call npm install --omit=dev
    echo.
)

:loop
echo Iniciando agente de impresion...
node agent.js
if %errorlevel% EQU 0 goto end

echo.
echo [%date% %time%] El agente se detuvo con error. Reiniciando en 5 segundos...
timeout /t 5 /nobreak >nul
goto loop

:end
pause
