/**
 * FacilComanda Print Agent
 *
 * Agente autónomo de impresión local.
 * Se conecta a RabbitMQ (conexión saliente) y despacha los tickets
 * directamente a las impresoras térmicas de la red local (LAN) por TCP.
 *
 * GARANTÍA: ningún ticket se descarta. Cada mensaje termina en uno de estos estados:
 *   1) Impreso en todas sus impresoras  -> se confirma (ack) y sale de la cola.
 *   2) Alguna impresora no respondió    -> pasa a la cola ".retry" y vuelve solo
 *                                          tras unos segundos (solo se reintentan
 *                                          las impresoras que fallaron).
 *   3) Se agotaron los reintentos       -> pasa a la cola ".failed", donde queda
 *                                          guardado. Se reencola con:
 *                                          node agent.js --requeue-failed
 *
 * Si el agente se cae a mitad de un ticket, RabbitMQ lo reentrega al volver
 * (puede salir duplicado, pero no se pierde).
 */

const amqp = require('amqplib');
const net = require('net');
const fs = require('fs');
const path = require('path');
const dns = require('dns');

// Preferir IPv4 al resolver nombres de host (evita timeouts por IPv6 sin salida real)
if (typeof dns.setDefaultResultOrder === 'function') {
  dns.setDefaultResultOrder('ipv4first');
}

// ---------------------------------------------------------------------------
// Logging: consola + archivo diario en ./logs (queda registro de lo impreso)
// ---------------------------------------------------------------------------
const LOG_DIR = path.join(__dirname, 'logs');
try {
  fs.mkdirSync(LOG_DIR, { recursive: true });
} catch (_) {
  // si no se puede crear la carpeta, se sigue solo con consola
}

function fmtMeta(m) {
  if (m instanceof Error) return m.stack || m.message;
  if (typeof m === 'string') return m;
  try {
    return JSON.stringify(m);
  } catch (_) {
    return String(m);
  }
}

function log(level, message, ...meta) {
  const ts = new Date().toISOString();
  console.log(`[${ts}] [${level}] ${message}`, ...meta);
  const extra = meta.length ? ' ' + meta.map(fmtMeta).join(' ') : '';
  const file = path.join(LOG_DIR, `agent-${ts.slice(0, 10)}.log`);
  fs.appendFile(file, `[${ts}] [${level}] ${message}${extra}\n`, () => {});
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ---------------------------------------------------------------------------
// Configuración
// ---------------------------------------------------------------------------
function loadConfig() {
  const configPath = path.join(__dirname, 'config.json');

  if (!fs.existsSync(configPath)) {
    console.error('[FATAL] No se encontró config.json en', configPath);
    process.exit(1);
  }

  let cfg;
  try {
    // replace: quita el BOM que algunos editores de Windows añaden al guardar
    const raw = fs.readFileSync(configPath, 'utf8').replace(/^\uFEFF/, '');
    cfg = JSON.parse(raw);
  } catch (err) {
    console.error('[FATAL] config.json no es un JSON válido:', err.message);
    process.exit(1);
  }

  if (cfg.organizationId === undefined || cfg.organizationId === null) {
    console.error('[FATAL] Falta "organizationId" en config.json');
    process.exit(1);
  }
  if (!cfg.rabbitmq || !cfg.rabbitmq.url) {
    console.error('[FATAL] Falta "rabbitmq.url" en config.json');
    process.exit(1);
  }

  return cfg;
}

const config = loadConfig();
const printerDefaults = config.printerDefaults || {};

// Intentos rápidos por impresora dentro de un mismo ciclo
const SOCKET_TIMEOUT_MS = printerDefaults.socketTimeoutMs || 3500;
const MAX_ATTEMPTS = printerDefaults.maxAttempts || 2;
const RETRY_DELAY_MS = printerDefaults.retryDelayMs || 1500;
// Ciclos de reintento diferido (vía cola .retry) antes de mandar a .failed
const MAX_RETRY_CYCLES = Number.isFinite(printerDefaults.maxRetryCycles) ? printerDefaults.maxRetryCycles : 20;
const RETRY_CYCLE_DELAY_MS = printerDefaults.retryCycleDelayMs || 30000;

const exchange = config.rabbitmq.exchange || 'facilcomanda.printer.topic';
const queueName = config.rabbitmq.queue || `facilcomanda_print_org_${config.organizationId}`;
const retryQueue = `${queueName}.retry`;
const failedQueue = `${queueName}.failed`;
const bindings = config.bindings || [`print.org.${config.organizationId}.#`];

// Heartbeat: detecta conexiones "muertas" (corte de red sin cierre limpio).
// Sin esto el agente puede creerse conectado y no recibir tickets.
function withHeartbeat(url, seconds = 30) {
  if (/[?&]heartbeat=/.test(url)) return url;
  return url + (url.includes('?') ? '&' : '?') + `heartbeat=${seconds}`;
}
const RABBIT_URL = withHeartbeat(config.rabbitmq.url);
const maskUrl = (u) => u.replace(/:[^:@/]+@/, ':****@');

// ---------------------------------------------------------------------------
// Impresión
// ---------------------------------------------------------------------------

/**
 * Envía un buffer raw ESC/POS a una impresora por TCP.
 * Resuelve cuando los datos ya fueron escritos al socket, aunque la
 * impresora no cierre la conexión por su lado (muchas no lo hacen).
 */
function sendToPrinter(ip, port, buffer, timeoutMs = SOCKET_TIMEOUT_MS) {
  return new Promise((resolve, reject) => {
    const socket = new net.Socket();
    let settled = false;
    let written = false;

    const cleanup = () => {
      socket.removeAllListeners('timeout');
      socket.removeAllListeners('error');
      socket.removeAllListeners('close');
      socket.removeAllListeners('connect');
    };

    const finish = (err) => {
      if (settled) return;
      settled = true;
      cleanup();
      socket.destroy();
      if (err) reject(err);
      else resolve({ success: true, ip, port });
    };

    socket.setTimeout(timeoutMs);

    socket.on('timeout', () => {
      if (written) {
        finish();
      } else {
        finish(new Error(`Timeout (${timeoutMs}ms) conectando a impresora ${ip}:${port}`));
      }
    });

    socket.on('error', (err) => {
      finish(new Error(`Fallo de red hacia impresora ${ip}:${port} - ${err.message}`));
    });

    socket.on('close', () => {
      if (written) {
        finish();
      } else {
        finish(new Error(`Conexión cerrada antes de enviar datos a ${ip}:${port}`));
      }
    });

    socket.connect(port, ip, () => {
      socket.write(buffer, (err) => {
        if (err) {
          finish(new Error(`Fallo al escribir en impresora ${ip}:${port} - ${err.message}`));
          return;
        }
        written = true;
        socket.end();
      });
    });
  });
}

function normalizePrinter(p) {
  const ip = p.ipAddress || p.ip;
  const port = Number(p.port) || 9100;
  const name = p.name || `${ip}:${port}`;
  return { ip, port, name };
}

const printerKey = (p) => `${p.ip}:${p.port}`;

/**
 * Impresoras destino: las que vienen en el mensaje o, si no hay,
 * las de respaldo de config.json filtradas por zona.
 */
function resolveTargetPrinters(data) {
  if (Array.isArray(data.printers) && data.printers.length > 0) {
    return data.printers;
  }

  const fallback = printerDefaults.fallbackPrinters;
  if (!Array.isArray(fallback)) return [];

  const locCode = (data.locationCode || 'COCINA').toUpperCase();
  const matching = fallback.filter((p) => {
    if (!p.locations || p.locations.length === 0) return true;
    return p.locations.map((l) => String(l).toUpperCase()).includes(locCode);
  });

  return matching.length > 0 ? matching : fallback;
}

/**
 * Imprime en paralelo en todas las impresoras indicadas, con intentos rápidos.
 * Devuelve las claves impresas y las impresoras que siguen fallando.
 */
async function printTicket(printers, rawBuffer) {
  const printed = [];
  let pending = printers.slice();

  for (let attempt = 1; attempt <= MAX_ATTEMPTS && pending.length > 0; attempt++) {
    const results = await Promise.all(
      pending.map(async (p) => {
        try {
          log('INFO', `Enviando ${rawBuffer.length} bytes a impresora "${p.name}" (${p.ip}:${p.port})...`);
          await sendToPrinter(p.ip, p.port, rawBuffer);
          log('INFO', `[OK] Impreso exitosamente en "${p.name}" (${p.ip}:${p.port})`);
          return { printer: p, ok: true };
        } catch (err) {
          log('ERROR', `[FALLO] No se pudo imprimir en "${p.name}" (${p.ip}:${p.port}): ${err.message}`);
          return { printer: p, ok: false };
        }
      })
    );

    results.filter((r) => r.ok).forEach((r) => printed.push(printerKey(r.printer)));
    pending = results.filter((r) => !r.ok).map((r) => r.printer);

    if (pending.length > 0 && attempt < MAX_ATTEMPTS) {
      await sleep(RETRY_DELAY_MS);
    }
  }

  return { printed, failed: pending };
}

// ---------------------------------------------------------------------------
// Utilidades RabbitMQ
// ---------------------------------------------------------------------------

function safeAck(ch, msg) {
  try {
    ch.ack(msg);
  } catch (err) {
    log('WARN', 'No se pudo confirmar el mensaje (canal cerrado). RabbitMQ lo reentregará:', err.message);
  }
}

function safeNack(ch, msg, requeue = false) {
  try {
    ch.nack(msg, false, requeue);
  } catch (err) {
    log('WARN', 'No se pudo devolver el mensaje a la cola (canal cerrado). RabbitMQ lo reentregará:', err.message);
  }
}

/** Publica en una cola y espera la confirmación del broker (publisher confirm). */
function publishConfirmed(ch, queue, content, options) {
  return new Promise((resolve, reject) => {
    ch.sendToQueue(queue, content, { persistent: true, ...options }, (err) => {
      if (err) reject(err);
      else resolve();
    });
  });
}

/** Quita los headers que RabbitMQ administra al dead-letterear. */
function cleanHeaders(headers) {
  const h = { ...(headers || {}) };
  for (const key of Object.keys(h)) {
    if (key === 'x-death' || key.startsWith('x-first-death') || key.startsWith('x-last-death')) {
      delete h[key];
    }
  }
  return h;
}

function baseOptions(msg, headers) {
  return {
    persistent: true,
    contentType: msg.properties.contentType,
    contentEncoding: msg.properties.contentEncoding,
    messageId: msg.properties.messageId,
    timestamp: msg.properties.timestamp,
    type: msg.properties.type,
    headers,
  };
}

/** Guarda el ticket en la cola de fallidos (nunca se descarta). */
async function parkFailed(ch, msg, reason, headers) {
  const h = {
    ...cleanHeaders(msg.properties.headers),
    ...(headers || {}),
    'x-failed-reason': String(reason).slice(0, 500),
    'x-failed-at': new Date().toISOString(),
  };
  await publishConfirmed(ch, failedQueue, msg.content, baseOptions(msg, h));
  log('ERROR', `Ticket guardado en la cola de fallidos '${failedQueue}' (${reason}). Reencolar con: node agent.js --requeue-failed`);
}

// ---------------------------------------------------------------------------
// Procesamiento de un ticket
// ---------------------------------------------------------------------------
async function processTicket(ch, msg) {
  const headers = msg.properties.headers || {};
  const cycles = Number(headers['x-cycles']) || 0;
  const alreadyPrinted = new Set(Array.isArray(headers['x-printed']) ? headers['x-printed'].map(String) : []);

  let data;
  try {
    data = JSON.parse(msg.content.toString('utf8'));
  } catch (err) {
    log('ERROR', 'Mensaje con JSON inválido:', err.message);
    await parkFailed(ch, msg, 'json-invalido');
    safeAck(ch, msg);
    return;
  }

  log('INFO', `=== NUEVO TICKET RECIBIDO ===${cycles > 0 ? ` (reintento, ciclo ${cycles})` : ''}`);
  if (msg.fields.redelivered) {
    log('WARN', 'Mensaje reentregado por RabbitMQ (el agente se cerró antes de confirmarlo). Puede salir duplicado.');
  }
  log(
    'INFO',
    `Job ID: ${data.jobId} | Orden: #${data.orderNumber} | Tipo: ${data.ticketType} | Zona: ${data.locationName || data.locationCode}`
  );
  log('INFO', `Mesa: ${data.tableName} | Mesero: ${data.waiterName || 'N/A'}`);

  if (!data.escposPayloadBase64) {
    log('WARN', `El ticket ${data.jobId} no contiene payload Base64.`);
    await parkFailed(ch, msg, 'sin-payload');
    safeAck(ch, msg);
    return;
  }

  const rawBuffer = Buffer.from(data.escposPayloadBase64, 'base64');

  const all = resolveTargetPrinters(data).map(normalizePrinter);
  all
    .filter((p) => !p.ip)
    .forEach((p) => log('ERROR', `Impresora "${p.name}" sin dirección IP en la configuración. Se omite.`));
  const valid = all.filter((p) => p.ip);

  if (valid.length === 0) {
    log('ERROR', `No hay impresoras válidas para la zona ${data.locationCode}.`);
    await parkFailed(ch, msg, 'sin-impresoras-validas');
    safeAck(ch, msg);
    return;
  }

  // En reintentos, saltar las impresoras donde ya salió (evita duplicados)
  const pending = valid.filter((p) => !alreadyPrinted.has(printerKey(p)));
  if (pending.length === 0) {
    log('INFO', `Ticket #${data.orderNumber} ya estaba impreso en todas sus impresoras.`);
    safeAck(ch, msg);
    return;
  }

  const { printed, failed } = await printTicket(pending, rawBuffer);
  const printedAll = [...new Set([...alreadyPrinted, ...printed])];

  if (failed.length === 0) {
    log('INFO', `Ticket #${data.orderNumber} impreso en ${printedAll.length}/${valid.length} impresoras.`);
    safeAck(ch, msg);
    return;
  }

  const failedKeys = failed.map(printerKey).join(', ');
  const nextCycles = cycles + 1;
  const newHeaders = {
    ...cleanHeaders(headers),
    'x-cycles': nextCycles,
    'x-printed': printedAll,
    'x-last-failure-at': new Date().toISOString(),
  };

  if (nextCycles > MAX_RETRY_CYCLES) {
    await parkFailed(ch, msg, `sin-respuesta-de-impresoras: ${failedKeys}`, newHeaders);
  } else {
    await publishConfirmed(ch, retryQueue, msg.content, {
      ...baseOptions(msg, newHeaders),
      expiration: String(RETRY_CYCLE_DELAY_MS),
    });
    log(
      'WARN',
      `Ticket #${data.orderNumber} pendiente en: ${failedKeys}. Reintento automático en ${Math.round(RETRY_CYCLE_DELAY_MS / 1000)}s (ciclo ${nextCycles}/${MAX_RETRY_CYCLES}).`
    );
  }

  // Solo se confirma el original después de que la copia quedó guardada
  safeAck(ch, msg);
}

async function handleMessage(ch, msg) {
  try {
    await processTicket(ch, msg);
  } catch (err) {
    log('ERROR', 'Error procesando ticket. Se intenta guardar en fallidos:', err);
    try {
      await parkFailed(ch, msg, `error-interno: ${err.message}`);
      safeAck(ch, msg);
    } catch (err2) {
      log('ERROR', 'No se pudo guardar en fallidos. Se descarta para evitar saturación de cola:', err2.message);
      safeNack(ch, msg, false);
    }
  }
}

// ---------------------------------------------------------------------------
// Agente
// ---------------------------------------------------------------------------
async function startAgent() {
  log('INFO', 'Iniciando FacilComanda Print Agent...');
  log('INFO', `Organización objetivo: ${config.organizationId}`);

  let connection = null;
  let channel = null;
  let reconnectTimer = null;
  let shuttingDown = false;

  function scheduleReconnect() {
    if (shuttingDown || reconnectTimer) return;
    const interval = config.rabbitmq.reconnectIntervalMs || 5000;
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      connect();
    }, interval);
  }

  /** Cierra la conexión actual (si existe) sin disparar reconexiones. */
  async function closeQuietly() {
    const conn = connection;
    connection = null;
    channel = null;
    if (!conn) return;
    conn.removeAllListeners('close');
    try {
      await conn.close();
    } catch (_) {
      // ya estaba cerrada
    }
  }

  /** La conexión, el canal o el consumidor se perdieron: reiniciar todo. */
  function handleLost(reason, conn) {
    if (shuttingDown || connection !== conn) return;
    log('WARN', `${reason}. Reintentando en unos segundos...`);
    closeQuietly().finally(scheduleReconnect);
  }

  async function connect() {
    try {
      log('INFO', `Conectando a RabbitMQ: ${maskUrl(RABBIT_URL)}`);

      const conn = await amqp.connect(RABBIT_URL);
      connection = conn;

      conn.on('error', (err) => {
        log('ERROR', 'Error en conexión RabbitMQ:', err.message);
      });
      conn.on('close', () => handleLost('Conexión RabbitMQ cerrada', conn));

      // Canal con confirmaciones: permite saber que la copia a retry/failed quedó guardada
      const ch = await conn.createConfirmChannel();
      channel = ch;

      // Sin listener de 'error' un fallo del canal tumba todo el proceso
      ch.on('error', (err) => {
        log('ERROR', 'Error en canal RabbitMQ:', err.message);
      });
      ch.on('close', () => handleLost('Canal RabbitMQ cerrado', conn));

      ch.prefetch(1);

      await ch.assertExchange(exchange, 'topic', { durable: true });

      // Cola principal (no se cambian sus argumentos para no chocar con la ya creada)
      const q = await ch.assertQueue(queueName, { durable: true });

      // Cola de reintentos: los mensajes esperan aquí y al expirar vuelven solos a la principal
      await ch.assertQueue(retryQueue, {
        durable: true,
        arguments: {
          'x-dead-letter-exchange': '',
          'x-dead-letter-routing-key': queueName,
        },
      });

      // Cola de fallidos: los tickets que no se pudieron imprimir quedan guardados
      const f = await ch.assertQueue(failedQueue, { durable: true });

      for (const pattern of bindings) {
        await ch.bindQueue(queueName, exchange, pattern);
        log('INFO', `Cola '${queueName}' vinculada al patrón: ${pattern}`);
      }

      if (q.messageCount > 0) {
        log('WARN', `Hay ${q.messageCount} ticket(s) pendientes en la cola. Se imprimirán ahora.`);
      }
      if (f.messageCount > 0) {
        log('WARN', `Hay ${f.messageCount} ticket(s) en la cola de fallidos. Revisar y reencolar con: node agent.js --requeue-failed`);
      }

      log('INFO', `Listo para imprimir. Esperando tickets en cola '${queueName}'...`);

      await ch.consume(
        queueName,
        (msg) => {
          if (!msg) {
            // El broker canceló el consumidor (cola borrada, failover, etc.)
            handleLost('Consumidor cancelado por RabbitMQ', conn);
            return;
          }
          handleMessage(ch, msg);
        },
        { noAck: false }
      );
    } catch (err) {
      log('ERROR', 'Fallo al iniciar conexión con RabbitMQ:', err.message);
      // Si llegó a conectar pero falló después, no dejar la conexión abierta
      await closeQuietly();
      scheduleReconnect();
    }
  }

  async function shutdown(signal) {
    if (shuttingDown) return;
    shuttingDown = true;
    log('INFO', `${signal} recibido. Cerrando agente...`);
    if (reconnectTimer) clearTimeout(reconnectTimer);
    await closeQuietly();
    process.exit(0);
  }

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  await connect();
}

// ---------------------------------------------------------------------------
// Modo utilitario: node agent.js --requeue-failed
// Mueve todos los tickets de la cola de fallidos de vuelta a la cola principal.
// Conserva "x-printed" para no duplicar en impresoras donde ya salieron.
// ---------------------------------------------------------------------------
async function requeueFailed() {
  log('INFO', `Reencolando tickets de '${failedQueue}' hacia '${queueName}'...`);
  const conn = await amqp.connect(RABBIT_URL);
  const ch = await conn.createConfirmChannel();
  await ch.assertQueue(queueName, { durable: true });
  await ch.assertQueue(failedQueue, { durable: true });

  let moved = 0;
  for (;;) {
    const msg = await ch.get(failedQueue, { noAck: false });
    if (!msg) break;

    const headers = cleanHeaders(msg.properties.headers);
    delete headers['x-cycles'];
    delete headers['x-failed-reason'];
    headers['x-requeued-at'] = new Date().toISOString();

    await publishConfirmed(ch, queueName, msg.content, baseOptions(msg, headers));
    ch.ack(msg);
    moved++;
  }

  log('INFO', `Listo. ${moved} ticket(s) devueltos a la cola principal.`);
  await conn.close();
}

process.on('unhandledRejection', (reason) => {
  log('ERROR', 'Promesa rechazada sin manejar:', reason);
});

if (process.argv.includes('--requeue-failed')) {
  requeueFailed()
    .then(() => process.exit(0))
    .catch((err) => {
      log('ERROR', 'Fallo reencolando tickets:', err);
      process.exit(1);
    });
} else {
  startAgent().catch((err) => {
    log('ERROR', 'Error fatal iniciando el agente:', err);
    process.exit(1);
  });
}
