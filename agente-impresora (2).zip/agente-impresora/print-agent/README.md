# FacilComanda Print Agent (Agente de Impresión Local)

Este programa corre en la computadora local del restaurante (Windows/Linux) y se encarga de recibir en tiempo real las comandas desde RabbitMQ y enviarlas por socket TCP directo a las impresoras térmicas de red local (`192.168.1.92:9100`, `192.168.1.90:9100`, etc.).

---

## 🎯 Ventajas frente al antiguo túnel SSH (`ComandaTunnel`)
1. **Conexión Saliente Resiliente:** El agente se conecta hacia el VPS (puerto 5673). No requiere abrir puertos en el router del restaurante ni configurar túneles SSH frágiles.
2. **Cero Agujeros Negros de Comandas:** Si la PC del restaurante pierde internet temporalmente, RabbitMQ retiene las comandas de manera segura en cola duradera. Al volver el internet, el agente se reconecta e imprime todos los pedidos pendientes de inmediato.
3. **Multi-Zona (Cocina, Barra, Parrilla):** El agente filtra o imprime por zonas específicas según la configuración de los productos.
4. **Reconexión Automática:** Reintenta la conexión de manera indefinida sin colgar los procesos del backend.

---

## 🚀 Requisitos
- [Node.js](https://nodejs.org/) (versión 18 o superior).

---

## ⚙️ Configuración (`config.json`)

```json
{
  "rabbitmq": {
    "url": "amqp://facilcomanda:FacilComandaPass2026!@srv1856499.hstgr.cloud:5673/facilcomanda",
    "exchange": "facilcomanda.printer.topic",
    "queue": "facilcomanda_print_agent_org5",
    "reconnectIntervalMs": 5000
  },
  "organizationId": 5,
  "bindings": [
    "print.org.5.#"
  ],
  "printerDefaults": {
    "socketTimeoutMs": 3500,
    "fallbackPrinters": [
      {
        "name": "Impresora Cocina 1",
        "ip": "192.168.1.92",
        "port": 9100,
        "locations": ["COCINA"]
      },
      {
        "name": "Impresora Cocina 2",
        "ip": "192.168.1.90",
        "port": 9100,
        "locations": ["COCINA"]
      }
    ]
  }
}
```

---

## 🧪 Ejecución Rápida
1. Abre una terminal en esta carpeta (`fc/print-agent`).
2. Instala dependencias:
   ```bash
   npm install
   ```
3. Inicia el agente:
   - Doble clic en `start-agent.bat` (o ejecuta `npm start`).

Verás en la consola:
```
[INFO] Conectando a RabbitMQ: amqp://facilcomanda:****@srv1856499.hstgr.cloud:5673/facilcomanda
[INFO] Cola 'facilcomanda_print_agent_org5' vinculada al patrón: print.org.5.#
[INFO] Listo para imprimir. Esperando tickets en cola...
```

---

## 🛡️ Instalar como Servicio de Windows (con NSSM)

Para que el agente arranque automáticamente al encender la PC y nunca se cierre:

1. Detén y elimina el antiguo servicio SSH (si ya no lo usas):
   ```cmd
   nssm stop ComandaTunnel
   nssm remove ComandaTunnel confirm
   ```

2. Instala el nuevo servicio `FacilComandaPrintAgent`:
   ```cmd
   nssm install FacilComandaPrintAgent "C:\Program Files\nodejs\node.exe" "C:\Users\USER\Documents\development\akilesgroup\facilcomanda\fc\print-agent\agent.js"
   nssm set FacilComandaPrintAgent AppDirectory "C:\Users\USER\Documents\development\akilesgroup\facilcomanda\fc\print-agent"
   nssm set FacilComandaPrintAgent AppStdout "C:\Users\USER\Documents\development\akilesgroup\facilcomanda\fc\print-agent\agent.log"
   nssm set FacilComandaPrintAgent AppStderr "C:\Users\USER\Documents\development\akilesgroup\facilcomanda\fc\print-agent\agent-error.log"
   nssm set FacilComandaPrintAgent AppRestartDelay 5000
   nssm start FacilComandaPrintAgent
   ```

¡Listo! El agente quedará corriendo en segundo plano como servicio permanente de Windows.
